import { combineReducers } from 'redux';
import readData from '../reducers/readReducer'

export default combineReducers({
  readData,
});